﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private float wynik = 0;
        private int id;
        private int id2 = 0;
        private string sciezka = "dane.txt";

        public Form1()
        {
            InitializeComponent();
            ZresetujWidok();
        }

        private void ZresetujWidok()
        {
            textBox1.Text = textBox2.Text = textBox3.Text = "";
            textBox4.Text = "";
            textBox9.Text = "";
            label3.Text = "";

            radioButton1.Checked = false;
            radioButton2.Checked = false;

            checkBox1.Checked = checkBox2.Checked = checkBox3.Checked = false;
            checkBox4.Checked = checkBox5.Checked = false;

            comboBox1.SelectedIndex = -1;

            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                checkedListBox1.SetItemChecked(i, false);
            }

            textBox1.Visible = textBox2.Visible = textBox3.Visible = false;
            label1.Visible = label2.Visible = label3.Visible = false;
            button1.Visible = button2.Visible = false;

            groupBox1.Visible = label4.Visible = label5.Visible = textBox4.Visible = false;

            label6.Visible = label7.Visible = label8.Visible = false;
            hScrollBar1.Visible = hScrollBar2.Visible = hScrollBar3.Visible = false;
            textBox5.Visible = textBox6.Visible = textBox7.Visible = textBox8.Visible = false;

            panel2.Visible = false;
        }

        private void AktualizujKolor()
        {
            int r = hScrollBar1.Value;
            int g = hScrollBar2.Value;
            int b = hScrollBar3.Value;

            textBox5.Text = r.ToString();
            textBox6.Text = g.ToString();
            textBox7.Text = b.ToString();
            textBox8.Text = $"Red {r}, Green {g}, Blue {b}";

            panel1.BackColor = Color.FromArgb(r, g, b);
        }

        private void kołoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 1;
            label1.Visible = textBox1.Visible = button1.Visible = true;
            label1.Text = "Podaj promień koła:";
        }

        private void prostokątToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 2;
            label1.Visible = label2.Visible = textBox1.Visible = textBox2.Visible = button1.Visible = true;
            label1.Text = "Podaj pierwszy bok prostokąta:";
            label2.Text = "Podaj drugi bok prostokąta:";
        }

        private void kwadratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 3;
            label1.Visible = textBox1.Visible = button1.Visible = true;
            label1.Text = "Podaj długość boku kwadratu:";
        }

        private void kołoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 4;
            label1.Visible = textBox1.Visible = button1.Visible = true;
            label1.Text = "Podaj promień koła:";
        }

        private void walecToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 5;
            label1.Visible = label2.Visible = textBox1.Visible = textBox2.Visible = button1.Visible = true;
            label1.Text = "Podaj promień podstawy walca:";
            label2.Text = "Podaj wysokość walca:";
        }

        private void stożekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 6;
            label1.Visible = label2.Visible = textBox1.Visible = textBox2.Visible = button1.Visible = true;
            label1.Text = "Podaj promień podstawy stożka:";
            label2.Text = "Podaj wysokość stożka:";
        }

        private void kulaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            id = 7;
            label1.Visible = textBox1.Visible = button1.Visible = true;
            label1.Text = "Podaj promień kuli:";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox3.Visible = label3.Visible = true;
            float promien, bok1, bok2, wysokosc;

            switch (id)
            {
                case 1:
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(Math.PI * promien * promien);
                    label3.Text = $"Pole koła o promieniu {promien} wynosi: ";
                    break;
                case 2:
                    bok1 = float.Parse(textBox1.Text);
                    bok2 = float.Parse(textBox2.Text);
                    wynik = bok1 * bok2;
                    label3.Text = $"Pole prostokąta o bokach {bok1} i {bok2} wynosi: ";
                    break;
                case 3:
                    bok1 = float.Parse(textBox1.Text);
                    wynik = bok1 * 4;
                    label3.Text = $"Obwód kwadratu o boku {bok1} wynosi: ";
                    break;
                case 4:
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(2 * Math.PI * promien);
                    label3.Text = $"Obwód koła o promieniu {promien} wynosi: ";
                    break;
                case 5:
                case 6:
                    promien = float.Parse(textBox1.Text);
                    wysokosc = float.Parse(textBox2.Text);
                    wynik = (float)(Math.PI * Math.Pow(promien, 2) * wysokosc);
                    label3.Text = $"Objętość bryły o promieniu {promien} i wys. {wysokosc} wynosi: ";
                    break;
                case 7:
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(4 * Math.PI * promien * promien);
                    label3.Text = $"Pole powierzchni kuli o promieniu {promien} wynosi: ";
                    break;
            }
            textBox3.Text = wynik.ToString("0.00");
        }

        private void sprawdźNazwiskoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            label2.Visible = textBox2.Visible = button2.Visible = true;
            label2.Text = "Podaj nazwisko";
            button2.Text = "Sprawdź";
        }

        private void rozwiążQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            label4.Visible = label5.Visible = textBox4.Visible = groupBox1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string szukaneNazwisko = textBox2.Text.Trim();

            if (!File.Exists(sciezka))
            {
                MessageBox.Show($"{szukaneNazwisko}, rozwiązujesz test po raz pierwszy.");
                return;
            }

            var linie = File.ReadAllLines(sciezka);
            var rekord = linie.FirstOrDefault(l => l.StartsWith(szukaneNazwisko + " "));

            if (rekord != null)
            {
                string[] dane = rekord.Split(' ');
                MessageBox.Show($"{dane[0]}, twój ostatni wynik z testu to {dane[1]} punktów.");
            }
            else
            {
                MessageBox.Show($"{szukaneNazwisko}, rozwiązujesz test po raz pierwszy.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string nazwisko = textBox9.Text.Trim();
            if (string.IsNullOrEmpty(nazwisko))
            {
                MessageBox.Show("Wprowadź nazwisko!");
                return;
            }

            int punkty = 0;
            List<int> bledy = new List<int>();

            if (textBox4.Text.Trim() == "8") punkty++;
            else bledy.Add(1);

            if (radioButton2.Checked) punkty++;
            else bledy.Add(2);

            if (checkBox1.Checked && !checkBox2.Checked && checkBox3.Checked && !checkBox4.Checked && checkBox5.Checked) punkty++;
            else bledy.Add(3);

            if (comboBox1.Text == "21") punkty++;
            else bledy.Add(4);

            if (checkedListBox1.GetItemChecked(0) && !checkedListBox1.GetItemChecked(1) && checkedListBox1.GetItemChecked(2) && !checkedListBox1.GetItemChecked(3) && checkedListBox1.GetItemChecked(4)) punkty++;
            else bledy.Add(5);

            string komunikat = $"Wynik quizu, {nazwisko}: {punkty} / 5 pkt.\n\n";

            if (bledy.Count > 0)
            {
                komunikat += "Pytania, w których popełniłeś błąd: " + string.Join(", ", bledy);
            }
            else
            {
                komunikat += "Gratulacje! Odpowiedziałeś bezbłędnie na wszystkie pytania.";
            }

            MessageBox.Show(komunikat, "Podsumowanie Quizu");

            var linie = File.Exists(sciezka) ? File.ReadAllLines(sciezka).ToList() : new List<string>();
            bool znaleziono = false;

            for (int i = 0; i < linie.Count; i++)
            {
                string[] dane = linie[i].Split(' ');
                if (dane[0] == nazwisko)
                {
                    znaleziono = true;
                    int starePunkty = int.Parse(dane[1].Split('/')[0]);
                    if (punkty > starePunkty)
                    {
                        linie[i] = $"{nazwisko} {punkty}/5";
                    }
                    break;
                }
            }

            if (!znaleziono) linie.Add($"{nazwisko} {punkty}/5");
            File.WriteAllLines(sciezka, linie);
        }

        private void koloryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            label6.Visible = label7.Visible = label8.Visible = true;
            hScrollBar1.Visible = hScrollBar2.Visible = hScrollBar3.Visible = true;
            textBox5.Visible = textBox6.Visible = textBox7.Visible = textBox8.Visible = true;
            AktualizujKolor();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e) => AktualizujKolor();
        private void hScrollBar2_Scroll(object sender, ScrollEventArgs e) => AktualizujKolor();
        private void hScrollBar3_Scroll(object sender, ScrollEventArgs e) => AktualizujKolor();

        private void kołoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            panel2.Visible = true;
            id2 = 1;
            panel2.Invalidate();
        }

        private void prostokatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            panel2.Visible = true;
            id2 = 2;
            panel2.Invalidate();
        }

        private void stożekToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            panel2.Visible = true;
            id2 = 3;
            panel2.Invalidate();
        }

        private void walecToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ZresetujWidok();
            panel2.Visible = true;
            id2 = 4;
            panel2.Invalidate();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen p = new Pen(Color.Black, 3);

            switch (id2)
            {
                case 1:
                    for (int i = 10; i <= 150; i += 5)
                    {
                        g.Clear(this.BackColor);
                        g.DrawEllipse(p, 200 - i / 2, 200 - i / 2, i, i);
                        Thread.Sleep(30);
                    }
                    break;
                case 2:
                    g.Clear(this.BackColor);
                    g.DrawRectangle(p, 100, 100, 200, 100);
                    for (int i = 0; i <= 100; i += 5)
                    {
                        g.DrawLine(p, 100, 100, 100 + (i * 2), 100 + i);
                        g.DrawLine(p, 300, 100, 300 - (i * 2), 100 + i);
                        Thread.Sleep(50);
                    }
                    break;
                case 3:
                    for (int i = 0; i <= 150; i += 5)
                    {
                        g.Clear(this.BackColor);
                        g.DrawLine(p, 200, 100, 100, 250);
                        g.DrawLine(p, 200, 100, 300, 250);
                        g.DrawEllipse(p, 100, 235, 200, 30);
                        g.DrawLine(p, 200, 100, 200, 100 + i);
                        Thread.Sleep(40);
                    }
                    break;
                case 4:
                    for (int i = 1; i <= 50; i++)
                    {
                        g.Clear(this.BackColor);
                        g.DrawEllipse(p, 150 - i, 70 - (i / 4), 2 * i, i / 2);
                        g.DrawEllipse(p, 150 - i, 220 - (i / 4), 2 * i, i / 2);
                        Thread.Sleep(20);
                    }
                    for (int j = 0; j <= 150; j += 2)
                    {
                        g.DrawLine(p, 100, 70, 100, 70 + j);
                        g.DrawLine(p, 200, 70, 200, 70 + j);
                        Thread.Sleep(10);
                    }
                    break;
            }
        }
    }
}