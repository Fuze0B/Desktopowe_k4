﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

/*po nacisnieciu na quiz (podmenu sprawdz nazwisko a drugie podmenu to rozwiąż quiz) pojawia się label podaj nazwisko, przycisk sprawdź po kliknięciu plik tekstowy w którym będą nazwiska i ilość punktów zdobytych za quiz np. Nazwisko kowalski to trzeba sprawdzić czy w pliku znajduje się nazwisko kowalski jeżeli się znajdzie niech wyskoczy okienko z komunikatem np. Kowalski twój ostatni wynik z testu to 3 punkty, ale jak nie znajdzie nazwiska w pliku to wyjdzie komunikat np. Kowalski rozwiązujesz test po raz pierwszy


2 zakladka rozwiąż quiz 5 pytań matematycznych różnego typu odpowiedzi (radio butony, lista jednokrotnego i wielokrotnego, checkboxy itp.) przycisk sprawdz odpowiedzi to wtedy messagebox "wynik quizu X punkty/punktów" 
jeżeli było już nazwisko to powinnismy albo zmienić liczbe punktów albo dopisać nowe nazwisko z nowa iloscia punktów i usunąć starszy rekord tylko wtedy jak liczba punktów była mniejsza niż nowy uzyskany wynik (funkcja split(" "))*/
//file.ReadAllText / ReadLineText





namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Visible = false;

            textBox2.Visible = false;

            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox4.Visible = false;
            button2.Visible = false;
            groupBox1.Visible = false;
        }
        private float wynik = 0;
        private int id;

        private void kołoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            button1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;

            label1.Text = "Podaj promień koła:";
            textBox1.Text = "";
            id = 1;
        }
        private void prostokątToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            label2.Visible=true;
            textBox2.Visible=true;
            button1.Visible = true;
            label1.Text = "Podaj pierwszy bok prostokąta:";
            label2.Text = "Podaj drugi bok prostokąta:";
            id = 2;

        }

        private void kwadratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            label1.Visible=true;
            textBox1.Visible=true;
            button1.Visible=true;
            label1.Text = "Podaj długość boku kwadratu";
            id = 3;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;
        }
        private void kołoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible=true;
            label2.Visible=false;
            textBox2.Visible = false;
            button1.Visible=true;
            textBox3.Visible=true;
            label3.Visible = true;
            label1.Text = "Podaj promień koła:";
            textBox1.Text = "";
            label3.Text = "";
            id = 4;
        }

        private void walecToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //objetosc
            id = 5;
            label1.Visible=true;
            textBox1.Visible=true;
            label2.Visible=true;
            textBox2.Visible=true;
            textBox1.Text = "";
            textBox2.Text = "";
            label1.Text = "Podaj promień podstawy walca";
            label2.Text = "Podaj wysokość walca";
            label3.Text = "";
            button1.Visible = true;
            textBox3.Visible = true;
            label3.Visible = true;
        }

        private void stożekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //objetosc
            id = 6;
            label1.Visible = true;
            textBox1.Visible = true;
            label2.Visible = true;
            textBox2.Visible = true;
            textBox1.Text = "";
            textBox2.Text = "";
            label1.Text = "Podaj promień podstawy stożka";
            label2.Text = "Podaj wysokość stożka";
            label3.Text = "";
            button1.Visible = true;
            textBox3.Visible = true;
            label3.Visible = true;
        }

        private void kulaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //pole powierzchni
            label1.Visible = true;
            textBox1.Visible = true;
            button1.Visible = true;
            label2.Visible = false;
            label3.Visible = false;
            textBox2.Visible = false;

            label1.Text = "Podaj promień kuli:";
            textBox1.Text = "";
            id = 7;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            switch (id) {

                case 1:
                    textBox3.Visible = true;
                    label3.Visible=true;
                    float promien = float.Parse(textBox1.Text);
                    wynik = (float)(Math.PI * promien * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole koła o promieniu " + promien + " wynosi: ";
                    break;
                case 2:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    float bok1 = float.Parse(textBox1.Text);
                    float bok2 = float.Parse(textBox2.Text);
                    wynik = bok1 * bok2;
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole prostokąta o bokach: " + bok1 + " oraz " + bok2 + " wynosi: ";
                    break;
                case 3:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    label3.Visible= true;
                    float bok = float.Parse(textBox1.Text);
                    wynik = bok * 4;
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Obwod kwadratu o boku " + bok + " wynosi: ";
                    break;
                case 4:
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(2 * Math.PI * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Obwod kola o promieniu " + promien + " wynosi: ";
                    break;
                case 5:
                    promien = float.Parse(textBox1.Text);
                    float wysokosc = float.Parse(textBox2.Text);
                    wynik = (float)(Math.PI * Math.Pow(promien,2)* wysokosc);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Objętość walca o promieniu podstawy " + promien + " i o wysokości "+wysokosc+" wynosi: ";
                    break;
                case 6:
                    promien = float.Parse(textBox1.Text);
                    wysokosc = float.Parse(textBox2.Text);
                    wynik = (float)((Math.PI * Math.Pow(promien, 2) * wysokosc));
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Objętość walca o promieniu podstawy " + promien + " i o wysokości " + wysokosc + " wynosi: ";
                    break;
                case 7:
                    textBox3.Visible = true;
                    label3.Visible = true;
                    promien = float.Parse(textBox1.Text);
                    wynik = (float)(4 * Math.PI * promien * promien);
                    textBox3.Text = wynik.ToString();
                    label3.Text = "Pole powierzchni kuli o promieniu " + promien + " wynosi: ";
                    break;
            }
        }

        private void sprawdźNazwiskoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label3.Visible = false;
            label2.Visible = true;
            label1.Visible = false;
            label3.Visible = false;
            textBox2.Visible = true;
            textBox1.Visible = false;
            textBox3.Visible = false;
            label2.Text = "Podaj nazwisko";
            button1.Visible = false;
            button2.Visible = true;
            button2.Text = "Sprawdź";

        }

        private void rozwiążQuizToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Visible = false;

            textBox2.Visible = false;

            textBox3.Visible = false;
            button1.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = true;
            label5.Visible = true;
            textBox4.Visible = true;
            groupBox1.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string sciezka = "dane.txt";
            string szukanyWyraz = textBox1.Text;
        }

        int wybor;

        private void kołoToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            groupBox5.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            textBox1.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;



        }
    }
}
