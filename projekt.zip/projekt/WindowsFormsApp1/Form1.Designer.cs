﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.obliczenieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figuryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prostokątToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.obwódToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kwadratToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bryłyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.objętośćToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.walecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stożekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polePowierzchniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kulaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rozwiążQuizToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sprawdźNazwiskoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.koloryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interpretacjaGeometrycznaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.figuryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kołoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.prostokatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bryłyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stożekToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.walecToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.hScrollBar2 = new System.Windows.Forms.HScrollBar();
            this.hScrollBar3 = new System.Windows.Forms.HScrollBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.obliczenieToolStripMenuItem,
            this.quizToolStripMenuItem,
            this.koloryToolStripMenuItem,
            this.interpretacjaGeometrycznaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1044, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // obliczenieToolStripMenuItem
            // 
            this.obliczenieToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.figuryToolStripMenuItem,
            this.bryłyToolStripMenuItem});
            this.obliczenieToolStripMenuItem.Name = "obliczenieToolStripMenuItem";
            this.obliczenieToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.obliczenieToolStripMenuItem.Text = "Obliczenie";
            // 
            // figuryToolStripMenuItem
            // 
            this.figuryToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.poleToolStripMenuItem,
            this.obwódToolStripMenuItem});
            this.figuryToolStripMenuItem.Name = "figuryToolStripMenuItem";
            this.figuryToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.figuryToolStripMenuItem.Text = "Figury";
            // 
            // poleToolStripMenuItem
            // 
            this.poleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kołoToolStripMenuItem,
            this.prostokątToolStripMenuItem});
            this.poleToolStripMenuItem.Name = "poleToolStripMenuItem";
            this.poleToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.poleToolStripMenuItem.Text = "Pole";
            // 
            // kołoToolStripMenuItem
            // 
            this.kołoToolStripMenuItem.Name = "kołoToolStripMenuItem";
            this.kołoToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.kołoToolStripMenuItem.Text = "Koło";
            this.kołoToolStripMenuItem.Click += new System.EventHandler(this.kołoToolStripMenuItem_Click);
            // 
            // prostokątToolStripMenuItem
            // 
            this.prostokątToolStripMenuItem.Name = "prostokątToolStripMenuItem";
            this.prostokątToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.prostokątToolStripMenuItem.Text = "Prostokąt";
            this.prostokątToolStripMenuItem.Click += new System.EventHandler(this.prostokątToolStripMenuItem_Click);
            // 
            // obwódToolStripMenuItem
            // 
            this.obwódToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kwadratToolStripMenuItem,
            this.kołoToolStripMenuItem1});
            this.obwódToolStripMenuItem.Name = "obwódToolStripMenuItem";
            this.obwódToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.obwódToolStripMenuItem.Text = "Obwód";
            // 
            // kwadratToolStripMenuItem
            // 
            this.kwadratToolStripMenuItem.Name = "kwadratToolStripMenuItem";
            this.kwadratToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.kwadratToolStripMenuItem.Text = "Kwadrat";
            this.kwadratToolStripMenuItem.Click += new System.EventHandler(this.kwadratToolStripMenuItem_Click);
            // 
            // kołoToolStripMenuItem1
            // 
            this.kołoToolStripMenuItem1.Name = "kołoToolStripMenuItem1";
            this.kołoToolStripMenuItem1.Size = new System.Drawing.Size(117, 22);
            this.kołoToolStripMenuItem1.Text = "Koło";
            this.kołoToolStripMenuItem1.Click += new System.EventHandler(this.kołoToolStripMenuItem1_Click);
            // 
            // bryłyToolStripMenuItem
            // 
            this.bryłyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.objętośćToolStripMenuItem,
            this.polePowierzchniToolStripMenuItem});
            this.bryłyToolStripMenuItem.Name = "bryłyToolStripMenuItem";
            this.bryłyToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.bryłyToolStripMenuItem.Text = "Bryły";
            // 
            // objętośćToolStripMenuItem
            // 
            this.objętośćToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.walecToolStripMenuItem,
            this.stożekToolStripMenuItem});
            this.objętośćToolStripMenuItem.Name = "objętośćToolStripMenuItem";
            this.objętośćToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.objętośćToolStripMenuItem.Text = "Objętość";
            // 
            // walecToolStripMenuItem
            // 
            this.walecToolStripMenuItem.Name = "walecToolStripMenuItem";
            this.walecToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.walecToolStripMenuItem.Text = "Walec";
            this.walecToolStripMenuItem.Click += new System.EventHandler(this.walecToolStripMenuItem_Click);
            // 
            // stożekToolStripMenuItem
            // 
            this.stożekToolStripMenuItem.Name = "stożekToolStripMenuItem";
            this.stożekToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.stożekToolStripMenuItem.Text = "Stożek";
            this.stożekToolStripMenuItem.Click += new System.EventHandler(this.stożekToolStripMenuItem_Click);
            // 
            // polePowierzchniToolStripMenuItem
            // 
            this.polePowierzchniToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kulaToolStripMenuItem});
            this.polePowierzchniToolStripMenuItem.Name = "polePowierzchniToolStripMenuItem";
            this.polePowierzchniToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.polePowierzchniToolStripMenuItem.Text = "Pole Powierzchni";
            // 
            // kulaToolStripMenuItem
            // 
            this.kulaToolStripMenuItem.Name = "kulaToolStripMenuItem";
            this.kulaToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.kulaToolStripMenuItem.Text = "Kula";
            this.kulaToolStripMenuItem.Click += new System.EventHandler(this.kulaToolStripMenuItem_Click);
            // 
            // quizToolStripMenuItem
            // 
            this.quizToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rozwiążQuizToolStripMenuItem,
            this.sprawdźNazwiskoToolStripMenuItem});
            this.quizToolStripMenuItem.Name = "quizToolStripMenuItem";
            this.quizToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.quizToolStripMenuItem.Text = "Quiz";
            // 
            // rozwiążQuizToolStripMenuItem
            // 
            this.rozwiążQuizToolStripMenuItem.Name = "rozwiążQuizToolStripMenuItem";
            this.rozwiążQuizToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.rozwiążQuizToolStripMenuItem.Text = "Rozwiąż quiz";
            this.rozwiążQuizToolStripMenuItem.Click += new System.EventHandler(this.rozwiążQuizToolStripMenuItem_Click);
            // 
            // sprawdźNazwiskoToolStripMenuItem
            // 
            this.sprawdźNazwiskoToolStripMenuItem.Name = "sprawdźNazwiskoToolStripMenuItem";
            this.sprawdźNazwiskoToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.sprawdźNazwiskoToolStripMenuItem.Text = "Sprawdź nazwisko";
            this.sprawdźNazwiskoToolStripMenuItem.Click += new System.EventHandler(this.sprawdźNazwiskoToolStripMenuItem_Click);
            // 
            // koloryToolStripMenuItem
            // 
            this.koloryToolStripMenuItem.Name = "koloryToolStripMenuItem";
            this.koloryToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.koloryToolStripMenuItem.Text = "Kolory";
            this.koloryToolStripMenuItem.Click += new System.EventHandler(this.koloryToolStripMenuItem_Click);
            // 
            // interpretacjaGeometrycznaToolStripMenuItem
            // 
            this.interpretacjaGeometrycznaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.figuryToolStripMenuItem1,
            this.bryłyToolStripMenuItem1});
            this.interpretacjaGeometrycznaToolStripMenuItem.Name = "interpretacjaGeometrycznaToolStripMenuItem";
            this.interpretacjaGeometrycznaToolStripMenuItem.Size = new System.Drawing.Size(163, 20);
            this.interpretacjaGeometrycznaToolStripMenuItem.Text = "Interpretacja geometryczna";
            // 
            // figuryToolStripMenuItem1
            // 
            this.figuryToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kołoToolStripMenuItem2,
            this.prostokatToolStripMenuItem});
            this.figuryToolStripMenuItem1.Name = "figuryToolStripMenuItem1";
            this.figuryToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.figuryToolStripMenuItem1.Text = "Figury";
            // 
            // kołoToolStripMenuItem2
            // 
            this.kołoToolStripMenuItem2.Name = "kołoToolStripMenuItem2";
            this.kołoToolStripMenuItem2.Size = new System.Drawing.Size(124, 22);
            this.kołoToolStripMenuItem2.Text = "Koło";
            this.kołoToolStripMenuItem2.Click += new System.EventHandler(this.kołoToolStripMenuItem2_Click);
            // 
            // prostokatToolStripMenuItem
            // 
            this.prostokatToolStripMenuItem.Name = "prostokatToolStripMenuItem";
            this.prostokatToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.prostokatToolStripMenuItem.Text = "Prostokat";
            this.prostokatToolStripMenuItem.Click += new System.EventHandler(this.prostokatToolStripMenuItem_Click);
            // 
            // bryłyToolStripMenuItem1
            // 
            this.bryłyToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stożekToolStripMenuItem1,
            this.walecToolStripMenuItem1});
            this.bryłyToolStripMenuItem1.Name = "bryłyToolStripMenuItem1";
            this.bryłyToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.bryłyToolStripMenuItem1.Text = "Bryły";
            // 
            // stożekToolStripMenuItem1
            // 
            this.stożekToolStripMenuItem1.Name = "stożekToolStripMenuItem1";
            this.stożekToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.stożekToolStripMenuItem1.Text = "Stożek";
            this.stożekToolStripMenuItem1.Click += new System.EventHandler(this.stożekToolStripMenuItem1_Click);
            // 
            // walecToolStripMenuItem1
            // 
            this.walecToolStripMenuItem1.Name = "walecToolStripMenuItem1";
            this.walecToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.walecToolStripMenuItem1.Text = "Walec";
            this.walecToolStripMenuItem1.Click += new System.EventHandler(this.walecToolStripMenuItem1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(9, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(9, 94);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(9, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Oblicz";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(9, 232);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Silver;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(24, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 38);
            this.label4.TabIndex = 8;
            this.label4.Text = "Quiz Matematyczny";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(265, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Pytanie 1: Rozwiąż równanie: 2x - 6 = 10. Ile wynosi x?";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(25, 126);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(268, 20);
            this.textBox4.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(9, 164);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(173, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(318, 477);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(117, 53);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 20);
            this.textBox9.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Podaj nazwisko:";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.Location = new System.Drawing.Point(97, 448);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(119, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "Wyślij odpowiedzi";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkedListBox1);
            this.groupBox5.Location = new System.Drawing.Point(25, 339);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(268, 103);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Pytanie 5: Zaznacz ułamki, które są równe 1/2:";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "2/4",
            "3/5",
            "5/10",
            "4/9",
            "50/100"});
            this.checkedListBox1.Location = new System.Drawing.Point(83, 19);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(101, 79);
            this.checkedListBox1.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Location = new System.Drawing.Point(25, 265);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(268, 75);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Pytanie 4: Jaki jest obwód trójkąta równobocznego o boku 7?";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "14",
            "21",
            "28",
            "49"});
            this.comboBox1.Location = new System.Drawing.Point(6, 35);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(262, 21);
            this.comboBox1.TabIndex = 14;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox5);
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Location = new System.Drawing.Point(25, 204);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(268, 55);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Pytanie 3: Które z podanych liczb są podzielne przez 3?";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(192, 32);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(38, 17);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "45";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(154, 32);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(38, 17);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "31";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(114, 32);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(38, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "24";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(76, 32);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(38, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "17";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(38, 32);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(38, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "12";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(25, 152);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(268, 46);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pytanie 2: Każdy kwadrat jest rombem.";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(165, 23);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(61, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.Text = "Prawda";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(49, 23);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(51, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "Fałsz";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(45, 175);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(232, 195);
            this.panel1.TabIndex = 2;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.LargeChange = 1;
            this.hScrollBar1.Location = new System.Drawing.Point(45, 12);
            this.hScrollBar1.Maximum = 255;
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(117, 20);
            this.hScrollBar1.TabIndex = 16;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // hScrollBar2
            // 
            this.hScrollBar2.LargeChange = 1;
            this.hScrollBar2.Location = new System.Drawing.Point(45, 51);
            this.hScrollBar2.Maximum = 255;
            this.hScrollBar2.Name = "hScrollBar2";
            this.hScrollBar2.Size = new System.Drawing.Size(117, 20);
            this.hScrollBar2.TabIndex = 17;
            this.hScrollBar2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar2_Scroll);
            // 
            // hScrollBar3
            // 
            this.hScrollBar3.LargeChange = 1;
            this.hScrollBar3.Location = new System.Drawing.Point(45, 92);
            this.hScrollBar3.Maximum = 255;
            this.hScrollBar3.Name = "hScrollBar3";
            this.hScrollBar3.Size = new System.Drawing.Size(117, 20);
            this.hScrollBar3.TabIndex = 18;
            this.hScrollBar3.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar3_Scroll);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Red";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Green";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Blue";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(177, 13);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 18;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(177, 51);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 21;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(177, 92);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 22;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(45, 131);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(232, 20);
            this.textBox8.TabIndex = 24;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(785, 38);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(247, 241);
            this.panel2.TabIndex = 25;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Controls.Add(this.label2);
            this.groupBox6.Controls.Add(this.textBox1);
            this.groupBox6.Controls.Add(this.textBox2);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Location = new System.Drawing.Point(0, 27);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(167, 477);
            this.groupBox6.TabIndex = 26;
            this.groupBox6.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.hScrollBar2);
            this.groupBox7.Controls.Add(this.textBox8);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.Controls.Add(this.panel1);
            this.groupBox7.Controls.Add(this.textBox6);
            this.groupBox7.Controls.Add(this.hScrollBar1);
            this.groupBox7.Controls.Add(this.textBox7);
            this.groupBox7.Controls.Add(this.label8);
            this.groupBox7.Controls.Add(this.textBox5);
            this.groupBox7.Controls.Add(this.hScrollBar3);
            this.groupBox7.Location = new System.Drawing.Point(497, 27);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(282, 477);
            this.groupBox7.TabIndex = 27;
            this.groupBox7.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1044, 505);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = " ";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem obliczenieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figuryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem poleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem obwódToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bryłyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prostokątToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem objętośćToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem walecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stożekToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polePowierzchniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kulaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kwadratToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem quizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rozwiążQuizToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sprawdźNazwiskoToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem koloryToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.HScrollBar hScrollBar3;
        private System.Windows.Forms.HScrollBar hScrollBar2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.ToolStripMenuItem interpretacjaGeometrycznaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem figuryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kołoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem prostokatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bryłyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem stożekToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem walecToolStripMenuItem1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
    }
}

