﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox1.Text);
            float b = float.Parse(textBox2.Text);
            float w = a + b;
            textBox3.Text = w.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox6.Text);
            float b = float.Parse(textBox5.Text);
            float w = a - b;
            textBox4.Text = w.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox9.Text);
            float b = float.Parse(textBox8.Text);
            float w = a * b;
            textBox7.Text = w.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            float a = float.Parse(textBox12.Text);
            float b = float.Parse(textBox11.Text);
            if (b == 0)
            {
                textBox10.Text = "Nie można dzielic przez 0";
            }
            else
            {
                float w = a / b;
                textBox10.Text = w.ToString();
            }
        }
    }
}
