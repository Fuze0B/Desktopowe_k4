﻿using System;
using System.Windows.Forms;

namespace RandomGrid
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[] tab;

        public void sort(int[] tab,int rozmiar)
        {
            int temp;
            for(int i = 0; i < rozmiar - 1; i++)
            {
                for(int j = 0; j < rozmiar - 1; j++)
                {
                    if (tab[j] > tab[j+1])
                    {
                        temp = tab[j];
                        tab[j] = tab[j + 1];
                        tab[j + 1] = temp;
                    }
                }
            }
            for(int k=0;k< rozmiar; k++)
            {
                dataGridView2.Rows[0].Cells[k].Value = tab[k];
            }
            
        }
        public int szukaj(int[] tab, int p, int k, int s)
        {
            int middleIndex = (p+k)/2;
            while (p <= k)
            {
                if (tab[middleIndex] == s)
                {
                    return middleIndex;
                }
                else if (s < tab[middleIndex])
                {
                    k = middleIndex - 1;
                }
                else
                {
                    p = middleIndex + 1;
                }
            }
                return 0;
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            textBox1.Visible = false;
            dataGridView2.Visible = false;

            tab = new int[dataGridView1.Columns.Count];
            Random random = new Random();
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    tab[j] = random.Next(1, 100);
                    dataGridView1.Rows[0].Cells[j].Value = tab[j];
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            label1.Text = "Min: ";
            int min = tab[0];
            for (int i = 0; i < tab.Length; i++)
            {
                if (tab[i] < min)
                {
                    min = tab[i];
                }
            }
            textBox1.Text = min.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
            label1.Text = "Max: ";
            int max = tab[0];
            for (int i = 0; i < tab.Length; i++)
            {
                if (tab[i] > max)
                {
                    max = tab[i];
                }
            }
            textBox1.Text = max.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = true;
            sort(tab, tab.Length);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Visible = true;
            textBox1.ReadOnly = false;
           // textBox1.Text = "";
            label2.Visible = true;
            label1.Visible = true;
           textBox1.Text = "25";
            label1.Text = "Element którego szukasz:";
            int s = Convert.ToInt32(textBox1.Text);
            szukaj(tab, 0, tab.Length - 1, s);
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
